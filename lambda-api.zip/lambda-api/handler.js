'use strict';
const AWS = require('aws-sdk');
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const { uuid } = require('uuidv4');
const db = new AWS.DynamoDB.DocumentClient({ apiVersion: '2012-08-10' });
AWS.config.update({
  region:"eu-west-2"
})

const usersTable = process.env.USERS_TABLE;
const surwayTable = process.env.SURWAY_TABLE;
const jwtSecret=process.env.JWT_SECRET;
// Create a response
function response_(statusCode,msg,data) {
  return {
    statusCode: statusCode,
    headers: {
      "Access-Control-Allow-Origin" : "*", // Required for CORS support to work
      "Access-Control-Allow-Credentials" : true // Required for cookies, authorization headers with HTTPS 
    },
    body: JSON.stringify({
      "status":statusCode, 
      "msg":msg,
      "data":data
      })
  };
}
//Get email
const getUserByEmail = async email => {
  let params = {
      TableName : usersTable,
      FilterExpression: "contains(#email, :email)",
      ExpressionAttributeNames: {
          "#email": "email",
      },
      ExpressionAttributeValues: {
          ":email": email,
      }       
  };
  const response = await db.scan(params).promise();
  return response.Items;
};
//Surway userId
const getSurwayByUserId = async userId => {
  let params = {
      TableName : surwayTable,
      FilterExpression: "contains(#userId, :userId)",
      ExpressionAttributeNames: {
          "#userId": "userId",
      },
      ExpressionAttributeValues: {
          ":userId": userId,
      }       
  };
  const response = await db.scan(params).promise();
  return response.Items;
};
//Get hash password
const hashPassword = async (password)=>{
  return bcrypt.hash(password,8);
}
//Compare password
const comparePassword = async (eventPassword, userPassword)=>{
  return bcrypt.compare(eventPassword, userPassword);
}
//Get JWT token
async function signToken(user) {
  const secret = Buffer.from(jwtSecret, "base64");
  return jwt.sign({ email: user.email, id: user.id, roles: ["USER"] }, secret, {
    expiresIn: 86400 // expires in 24 hours
  });
}
//Verify JWT tokwn
async function getUserFromToken(token) {
  const secret = Buffer.from(process.env.JWT_SECRET, "base64");
  const decoded = jwt.verify(token.replace("Bearer ", ""), secret);
  return decoded;
}
//Check email pattern is valid
const validEmail = async email => {
  const emailToValidate = 'a@a.com';
  const emailRegexp = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  return (emailRegexp.test(email));
};
// SignUp user
module.exports.signUp = async(event, context, callback) => {
  try
  {
    const reqBody = JSON.parse(event.body);
    if(!reqBody || !reqBody.email || reqBody.email.trim() === '' || !reqBody.password || reqBody.password.trim() === '' || !reqBody.confirm_password || reqBody.confirm_password.trim() === '')
    {
      return callback(null,
        response_(400,"Email, password and confirm_password field is required and not empty.",[]));
    }else if(reqBody.password != reqBody.confirm_password){
      return callback(null,
        response_(400,"Confirm password must be equal to password.",[]));
    }
    const isValidEmail = await validEmail(reqBody.email);
    if(isValidEmail==false) {
      return callback(null,response_(400,"invalid email address format",[]));
    }

    const user = await getUserByEmail(reqBody.email);
    if(user.length>0){
      callback(null, response_(400,'Sorry this email id is already registered.',[]));
    }

    const passwordHash = await hashPassword(reqBody.password);
    const params = {
        id: uuid(),
        createdAt: new Date().toISOString(),
        email: reqBody.email,
        password: passwordHash
    };

    return db.put({
      TableName: usersTable,
      Item: params
    }).promise().then(() => {
      callback(null,response_(200,"Registration completed successfully.",[]));
    }).catch((err) => response_(err.statusCode,'fail.',err));
  }catch(e){
    callback(null, response_(500,'fail.',e))
  }  
};
// SignIn user
module.exports.signIn = async(event, context, callback) => {
  try {
    const reqBody = JSON.parse(event.body);
    if(!reqBody || !reqBody.email || reqBody.email.trim() === '' || !reqBody.password || reqBody.password.trim() === ''){
      return callback(null,response_(400,"Email and password field is required and not empty.",[]));
    }else{
      const user = await getUserByEmail(reqBody.email);
      if(user.length>0){
        const isValidPassword = await comparePassword(
          reqBody.password,
          user[0].password
        );
        if(isValidPassword==true){
          const token = await signToken(user[0]);
            callback(null,response_(200,"Login successfully.",token));        
        }else{
            callback(null,response_(400,"Authentication fail.",[]));
        }    
      }else{
        callback(null,response_(400,"Authentication fail.",[]));
      }
    }
  }catch(e){
    callback(null, response_(500,'fail',e))
  } 
};
// Verify Token
module.exports.verifyToken = async(event, context, callback) => {
  try
  {
    const reqBody = JSON.parse(event.body);
    const userObj = await getUserFromToken(event.headers.Authorization);
    return userObj;
    //callback(null,response_(200,"Token Verified.",userObj));
  }
  catch(e){
    return false;
    //callback(null, response_(401,'Authorization fail.',e))
  }  
};
// SignOut
module.exports.signOut = (event, context, callback) => {
  return callback(null, response_(200, "signOut"));
};
// Create surway
module.exports.createSurway = async(event, context, callback) => {
  try
  {
    const jwtVerify = await this.verifyToken(event, context, callback);
    if(!jwtVerify){
      return callback(null,response_(401,"Authentication fail",[])); 
    }

    const reqBody = JSON.parse(event.body);
    if(!reqBody || !reqBody.active || reqBody.active.trim() === '' || !reqBody.name || reqBody.name.trim() === '' || !reqBody.expireDate || reqBody.expireDate.trim() === '' || !reqBody.url || reqBody.url.trim() === '' || !reqBody.fromEmail || reqBody.fromEmail.trim() === '' || !reqBody.trigger || reqBody.trigger.trim() === '' || !reqBody.accessibility || reqBody.accessibility.trim() === '')
    {
      callback(null,
        response_(400,"Active,name,expireDate,url,fromEmail,trigger and accessibility field is required and not empty.",[]));
    }else{
      const isValidEmail = await validEmail(reqBody.fromEmail);
      if(isValidEmail==false) {
        return callback(null,response_(400,"invalid email address format",[]));
      }
      
      const isSurwayAlreadyDid = await getSurwayByUserId(jwtVerify.id);
      if(isSurwayAlreadyDid.length>0){
        return callback(null,response_(400,"Sorry you alrady did surway.",[])); 
      }

      const params = {
        id: uuid(),
        createdAt: new Date().toISOString(),
        userId: jwtVerify.id,
        active: reqBody.active,
        name: reqBody.name,
        expireDate: reqBody.expireDate,
        url: reqBody.url,
        fromEmail: reqBody.fromEmail,
        trigger: reqBody.trigger,
        accessibility: reqBody.accessibility
      };
      return db.put({
        TableName: surwayTable,
        Item: params
      }).promise().then(() => {
        callback(null,response_(200,"Thank you for survey feedback.",[]));
      }).catch((err) => response_(err.statusCode,'fail.',err));
    }
  }catch(e){
    callback(null, response_(500,'fail.',e));
  }  
};
// Get surway
module.exports.getSurway = async(event, context, callback) => {
  try
  {
    const jwtVerify = await this.verifyToken(event, context, callback);
    if(!jwtVerify){
      return callback(null,response_(401,"Authentication fail",[])); 
    }
    const surway = await getSurwayByUserId(jwtVerify.id);
    return callback(null,response_(200,"Success",surway)); 
  }catch(e){
    callback(null, response_(500,'fail.',e));
  }
};