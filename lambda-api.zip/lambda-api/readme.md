# Follow the steps for basic LAMBDA API configurations
1. Go to root directory lambda-api.
2. I assume you have alrady configure aws cli with appropriate region.
3. Open your terminal and run below command 
```
npm install
```
4. Deploy API into the aws LAMBDA. run below command
```
sls deploy
```
6. Find postman collection and import. set env variable into postman environment with below variable name and url
```
surway_auth = https://ywzjrqroxk.execute-api.eu-west-2.amazonaws.com/dev
```

## Good Luck