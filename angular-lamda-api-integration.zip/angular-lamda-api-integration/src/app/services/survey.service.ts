import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class SurveyService {
  constructor(public http: HttpClient) { }
  
  create_servey(data:any){
    return this.http.post('surway',data);
  }
  get_survey(){
    return this.http.get('surway');
  }
}
