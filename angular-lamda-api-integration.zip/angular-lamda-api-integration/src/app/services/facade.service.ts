import { Injectable, Injector } from "@angular/core";
import { LoginService } from "./login.service";
import { SurveyService } from "./survey.service";
import swal from "sweetalert2";
import { NgxSpinnerService } from "ngx-spinner";
import { environment as env } from "../../environments/environment";
@Injectable({
  providedIn: "root"
})
export class FacadeService {
  env:any=env;
  private _loginService: LoginService;
  private _surveyService: SurveyService;

  constructor(private injector: Injector,
    private spinner: NgxSpinnerService) {}
  
  public get surveyService(): SurveyService {
    if (!this._surveyService) {
      this._surveyService = this.injector.get(SurveyService);
    }
    return this._surveyService;
  }
  public get loginService(): LoginService {
    if (!this._loginService) {
      this._loginService = this.injector.get(LoginService);
    }
    return this._loginService;
  }
  signUp(param: any) {
    return this.loginService.register(param);
  }
  signIn(param: any) {
    return this.loginService.login(param);
  }
  isAuthenticated() {
    return this.loginService.isAuthenticated();
  }
  authorize(token: any) {
    return this.loginService.authorize(token);
  }
  logout() {
    return this.loginService.logout();
  }
  auth() {
    return this.loginService.auth();
  }
  create_servey(data: any) {
    return this.surveyService.create_servey(data);
  }
  get_survey(){
    return this.surveyService.get_survey();
  }
  swal_success(msg: any) {
    swal.fire("", msg, "success");
  }
  swal_fail(msg: any) {
    swal.fire({
      icon: "error",
      text: msg
    });
  }
  show(){
    this.spinner.show();
  }
  hide(){
    this.spinner.hide();
  }
}