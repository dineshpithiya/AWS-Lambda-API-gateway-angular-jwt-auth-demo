import { Injectable, Injector } from "@angular/core";
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class LoginService {
  private message: string;
  location_:any;
  constructor(
    private injector: Injector,
    public http: HttpClient,
    private _router: Router
  ) { 
  }

  clear(): void {
    localStorage.clear();
  }
  register(param:any){
    return this.http.post('signUp',param);
  }
  login(param:any){
    return this.http.post('signIn',param);
  }
  authorize(auth:any): void {
    localStorage.setItem('auth', JSON.stringify(auth));
    this._router.navigate(['/survey']);
  }
  isAuthenticated(): boolean {
    return this.auth()?(this.auth().token?true:false):false;
  }
  auth() {
    return JSON.parse(localStorage.getItem('auth'));
  }
  logout(){
    this.clear();
    this._router.navigate(['/sign-in']);
  } 
}
