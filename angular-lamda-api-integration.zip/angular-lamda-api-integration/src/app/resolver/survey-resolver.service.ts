import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { take, map } from 'rxjs/operators';
import { SurveyService } from "../services/survey.service";

import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class surveyResolverService implements Resolve <Observable<any>>{

  constructor(private service: SurveyService) { }

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot){
    return this.service.get_survey().pipe(
      take(1),
      map((data:any) => data.data)
    )
  }
}