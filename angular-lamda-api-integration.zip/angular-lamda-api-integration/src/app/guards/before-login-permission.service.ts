import { Injectable } from '@angular/core';
import { CanActivate,ActivatedRoute, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { FacadeService } from '../services/facade.service';
@Injectable({
  providedIn: 'root'
})
export class beforeLoginPermissionService implements CanActivate {
  routerEvents: any;
  constructor(
    private route: ActivatedRoute,
    private service: FacadeService, 
    private router: Router) {
  }
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    if(this.service.isAuthenticated())
    {
        this.service.authorize(this.service.auth());
    }else{
      return true;
    }  
  }
}
