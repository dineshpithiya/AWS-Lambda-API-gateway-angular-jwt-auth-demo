import { Component,Output,EventEmitter } from '@angular/core';
@Component({
  selector: 'ngbd-datepicker-popup',
  templateUrl: './datepicker-popup.html'
})
export class NgbdDatepickerPopup {
  model:any;
  @Output() onChangeDate: EventEmitter<any> = new EventEmitter<any>();
  onChooseDate(e:any){
    this.onChangeDate.emit(e);
  }
}
