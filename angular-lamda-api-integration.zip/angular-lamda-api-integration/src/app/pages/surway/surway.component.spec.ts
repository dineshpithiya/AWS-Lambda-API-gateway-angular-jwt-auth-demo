import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SurwayComponent } from './surway.component';

describe('SurwayComponent', () => {
  let component: SurwayComponent;
  let fixture: ComponentFixture<SurwayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SurwayComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SurwayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
