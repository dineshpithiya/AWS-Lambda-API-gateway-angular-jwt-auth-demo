import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FacadeService } from "../../services/facade.service";
@Component({
  selector: 'app-surway',
  templateUrl: './surway.component.html',
  styleUrls: ['./surway.component.css']
})
export class SurwayComponent implements OnInit {
  submitForm: FormGroup;
  submitted = false;
  returnUrl: string;
  model:any;
  trigger:any=[];
  survey:any;
  constructor(
    private service : FacadeService,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private router: Router){
      if(this.route.snapshot.data.verified.length>0){
        this.survey=this.route.snapshot.data.verified[0];
        setTimeout(() => {
          this.readyOnlyForm();
        }, 1000);
      }
    }
  ngOnInit(): void {
    const reg = '(https?://)?([\\da-z.-]+)\\.([a-z.]{2,6})[/\\w .-]*/?';
    this.submitForm = this.formBuilder.group({
      active:['',Validators.required],
      name:['',Validators.required],
      expireDate:['',Validators.required],
      url:['',[Validators.required,Validators.pattern(reg)]],
      fromEmail: ['', [Validators.required, Validators.email]],
      trigger_1:[''],
      trigger_2:[''],
      trigger:['',Validators.required],
      accessibility: ['', [Validators.required]]
    });
  }
  get active() { return this.submitForm.get('active') };
  get f() { return this.submitForm.controls; }
  onChangeDate(e:any){
    this.submitForm.patchValue({
      expireDate:e.year+'-'+e.month+'-'+e.day
    });
  }
  onCheckTrigger(e:any){
    if(e.target.checked){
      this.trigger.push(e.target.value);
    }else{
      const index = this.trigger.findIndex(x => x === e.target.value);
      if (index !== -1) {
        this.trigger.splice(index, 1);
      }   
    }
    this.submitForm.patchValue({trigger:JSON.stringify(this.trigger)});
  }
  resetForm(){
    if(confirm("Are you sure, you wan't reset form?")){
      this.submitForm.reset();
      this.submitted = false;
    }
  }
  readyOnlyForm(){
    this.submitForm.patchValue(this.survey);
      let _json=JSON.parse(this.survey.trigger);
      _json.map((trigger:any)=>{
        if(trigger==1){
          this.submitForm.patchValue({trigger_1:1});
        }
        if(trigger==2){
          this.submitForm.patchValue({trigger_2:2});
        }
      })
    this.submitForm.disable()
  }
  onSubmit() {
    this.submitted = true;
    if (this.submitForm.invalid) {
      return;
    }
    if(this.trigger.length<1){
      return false;
    }
    this.service.create_servey(this.submitForm.value).subscribe((data:any)=>{
      this.service.swal_success(data.msg);
      this.survey=this.submitForm.value;
      this.readyOnlyForm();
    })
  }  
}
