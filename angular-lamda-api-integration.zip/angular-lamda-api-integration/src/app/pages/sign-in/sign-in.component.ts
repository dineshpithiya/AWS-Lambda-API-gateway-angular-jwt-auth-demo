import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FacadeService } from "../../services/facade.service";
@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css']
})
export class SignInComponent implements OnInit {
  submitForm: FormGroup;
  submitted = false;
  returnUrl: string;
  constructor(
    private service : FacadeService,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private router: Router){ 

    }
  ngOnInit(): void {
    this.submitForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(3)]]
    });
  }
  get f() { return this.submitForm.controls; }
  onSubmit() {
    this.submitted = true;
    if (this.submitForm.invalid) {
      return;
    }
    let _email=this.submitForm.value.email;
    this.service.signIn(this.submitForm.value).subscribe((data:any)=>{
      this.submitted = false;
      this.submitForm.reset();
      let profile={
        email:_email,
        token:data.data
      }
      this.service.authorize(profile);
      this.router.navigate(['/survey']);
    })
  }  
}
