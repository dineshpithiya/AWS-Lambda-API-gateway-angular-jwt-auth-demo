import { Component, OnInit } from '@angular/core';
import { FacadeService } from "../../../services/facade.service";
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  auth:any="";
  constructor(private service : FacadeService) { }
  ngOnInit(): void {
    this.auth=this.service.auth()?this.service.auth().email:"";
  }
  signOut(){
    this.service.logout();
  }
}
