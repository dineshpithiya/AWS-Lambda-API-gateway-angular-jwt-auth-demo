import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MustMatch } from '../../helper/must-match.validator';
import { FacadeService } from "../../services/facade.service";
@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
  submitForm: FormGroup;
  submitted = false;
  returnUrl: string;
  constructor(
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private service : FacadeService,
    private router: Router){ 

    }
  ngOnInit(): void {
    this.submitForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8)]],
      confirm_password: ['', Validators.required]
    },{
      validator: MustMatch('password', 'confirm_password')
    });
  }
  get f() { return this.submitForm.controls; }
  onSubmit() {
    this.submitted = true;
    if (this.submitForm.invalid) {
      return;
    }
    this.service.signUp(this.submitForm.value).subscribe((data:any)=>{
      this.service.swal_success(data.msg);
      this.submitForm.reset();
      this.router.navigate(['/sign-in']);
    })
  }  
}
