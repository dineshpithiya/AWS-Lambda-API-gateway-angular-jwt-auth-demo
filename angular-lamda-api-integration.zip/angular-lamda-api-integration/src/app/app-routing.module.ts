import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { SignUpComponent } from './pages/sign-up/sign-up.component';
import { SignInComponent } from './pages/sign-in/sign-in.component';
import { SurwayComponent } from './pages/surway/surway.component';
import { BodyComponent } from './pages//layout/body/body.component';
import { beforeLoginPermissionService } from "./guards/before-login-permission.service";
import { AuthGuardService } from './guards/auth-guard.service';
import { surveyResolverService } from "./resolver/survey-resolver.service";

const routes: Routes = [
  {
    path: '',
    component: BodyComponent,
    canActivate: [],
    children: [
      {
        path: '',
        component: HomeComponent,
        pathMatch: 'full',
        canActivate: []
      }
    ]
  },
  { 
    path: 'sign-in' , 
    component: SignInComponent,
    canActivate: [beforeLoginPermissionService]
  },
  { 
    path: 'sign-up' , 
    component: SignUpComponent,
    canActivate: [beforeLoginPermissionService]
  },
  {
    path: '',
    component: BodyComponent,
    canActivate: [AuthGuardService],
    children: [
      {
        path: 'survey',
        component: SurwayComponent,
        pathMatch: 'full',
        canActivate: [AuthGuardService],
        resolve: {
          verified: surveyResolverService
        }
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
