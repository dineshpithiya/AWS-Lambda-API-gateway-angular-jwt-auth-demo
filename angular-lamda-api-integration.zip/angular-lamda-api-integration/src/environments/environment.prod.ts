export const environment = {
  production: true,
  host:"https://ywzjrqroxk.execute-api.eu-west-2.amazonaws.com/dev/"
};
