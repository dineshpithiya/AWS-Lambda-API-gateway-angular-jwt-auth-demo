# Follow the steps to install and configure angular with LAMBDA api.
1. Go to folder root directory angular-lamda-api-integration
2. I assume you have already installed angular CLI. if not then please install latest version.
3. Run below command
```
npm install
```
4. Now run angular application
```
ng serve
```
5. Open below URL into your browser
```
http://localhost:4200
```
